package SimpsonFarzanaNovela.com.adsnoobs.sqliteappexemplo;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Lg extends AppCompatActivity {
    private EditText edtNom;
    private EditText edtUse;
    private Button btnlog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        startActivity(new Intent(Lg.this, MainActivity.class));
    }
}
