package SimpsonFarzanaNovela.com.adsnoobs.sqliteappexemplo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

public class Dados_da_Disciplina extends AppCompatActivity {

    private EditText edtNomeEstudante;
    private EditText       edtDisciplina;
    private EditText edtprofessor;
    private EditText        edtContacto;
    private EditText  edtDescricaoD;
    private Button btnAdicionar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dados_da__disciplina);




    }
}
